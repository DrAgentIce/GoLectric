package com.example.hackscjava;

import android.location.Location;

import java.text.SimpleDateFormat;

public class DistanceTraveled
{
    private float distanceTraveled;
    private String dateStarted;
    private Location lastLocation;

    public DistanceTraveled() {
    }

    public DistanceTraveled(Location location) {
        distanceTraveled = 0;

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        dateStarted = format.format(location.getTime());
    }

    public float getDistanceTraveled() {
        return distanceTraveled;
    }

    public void incDistTraveled(Location location) {

        if(lastLocation == null)
        {
            lastLocation = location;
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            dateStarted = format.format(location.getTime());
        }else {
            this.distanceTraveled += lastLocation.distanceTo(location)*0.000621371;
            lastLocation = location;
        }
    }

    public String getDateStarted()
    {
        return getDateStarted();
    }
}
