package com.example.hackscjava;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.viewpager2.widget.ViewPager2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import fr.quentinklein.slt.LocationTracker;
import fr.quentinklein.slt.TrackerSettings;

public class MainActivity extends AppCompatActivity {

    private OnboardingAdapter onboardingAdapter;
    private MaterialButton buttonOnboardingAction;
    private LinearLayout layoutOnboardingIndicators;

    private DistanceTraveled trip = new DistanceTraveled();
    final int MY_PERMISSIONS_REQUEST_LOCATION = 100;
    private CarDatabase carDatabase = new CarDatabase();
    private Location location;
    private ElectricCarCalculator electricCarCalculator;
    private String state;
    private readwrite readwrite;
    private CarData car = new CarData();
    File file = new File("SavedData");

    private TextView CarbonEmissionGas;
    private TextView CarbonEmissionElectric;
    private TextView CarbonEmissionDifferance;
    private TextView PriceGas;
    private TextView PriceElectric;
    private TextView PriceDiff;
    private TextView  moneySaved;
    private TextView distanceTxt;
    private boolean inMainMenu = false;

    private EditText mpg;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layoutOnboardingIndicators = findViewById(R.id.layoutOnboardingIndicators);

        buttonOnboardingAction = findViewById(R.id.buttonOnboardingAction);

        setupOnboardingItems();
        final ViewPager2 onboardingViewPager = findViewById(R.id.onboardingViewPager);
        onboardingViewPager.setAdapter(onboardingAdapter);

        setupOnboardingIndicators();
        setCurrentOnboardingIndicator(0);

        buttonOnboardingAction.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(onboardingViewPager.getCurrentItem() + 1 < onboardingAdapter.getItemCount()){
                    onboardingViewPager.setCurrentItem(onboardingViewPager.getCurrentItem()+1);
                }else{

                    mpg = findViewById(R.id.mpg);
                    String mpgString = mpg.getText().toString().trim();
                    Float mpgValue = Float.parseFloat(mpgString);
                    car.setMPG(mpgValue);

                    setContentView(R.layout.activity_home);
                    CarbonEmissionGas = findViewById(R.id.CarbomEmissionGas);
                    CarbonEmissionElectric = findViewById(R.id.CarbonEmissionElectric);
                    CarbonEmissionDifferance = findViewById(R.id.CarbonEmissionDiff);
                    PriceGas = findViewById(R.id.gasPrice);
                    PriceElectric = findViewById(R.id.ElectricPrice);
                    PriceDiff = findViewById(R.id.PriceDifference);
                    distanceTxt = findViewById(R.id.Distance);
                    moneySaved = findViewById(R.id.MoneySaved);
                    inMainMenu = true;
                }

            }
        });


        //Setup and Track distance
        if (    ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_LOCATION);
        }
        else
        {
            TrackerSettings settings =
                    new TrackerSettings()
                            .setUseGPS(true)
                            .setUseNetwork(true)
                            .setUsePassive(true)
                            .setTimeBetweenUpdates(1000)
                            .setMetersBetweenUpdates(100);

            LocationTracker tracker = new LocationTracker(this, settings) {

                @Override
                public void onLocationFound(Location location) {
                    setStartLocation(location);
                    if (location.getSpeed() > 6.7f && inMainMenu) {

                        trip.incDistTraveled(location);

                        distanceTxt.setText(Float.toString(trip.getDistanceTraveled()));

                        float dist = trip.getDistanceTraveled();

                        PriceGas.setText("$"+ Float.toString(electricCarCalculator.PriceGas(dist,car)));
                        PriceElectric.setText("$"+ Float.toString(electricCarCalculator.PriceElectric(dist)));
                        PriceDiff.setText("$"+ Float.toString(electricCarCalculator.Pricedifference(dist,car)));
                        moneySaved.setText("$"+ Float.toString(electricCarCalculator.Pricedifference(dist,car)));

                        CarbonEmissionGas.setText(Float.toString(electricCarCalculator.CarbonEmissionGas(dist,car))+ " kgs CO2");
                        CarbonEmissionElectric.setText(Float.toString(electricCarCalculator.CarbonEmissionElectric(dist))+ " kgs CO2");
                        CarbonEmissionDifferance.setText(Float.toString(electricCarCalculator.CarbonEmissionSavedByElectric(dist,car))+ " kgs CO2");
                    }
                }

                @Override
                public void onTimeout() {
                }
            };
            tracker.startListening();
        }
    }

   protected void setStartLocation(Location location)
    {
        if (this.location == null)
        {
            this.location = location;
        }

        electricCarCalculator = new ElectricCarCalculator(this, this.location);
        state = electricCarCalculator.getState();
        //stateTxt.setText(electricCarCalculator.getState());

    }

    private void setupOnboardingItems(){
        List<OnboardingItem> onboardingItems = new ArrayList<>();

        OnboardingItem firstScreen = new OnboardingItem();
        firstScreen.setTitle("GoLectric");
        firstScreen.setDescription("Welcome! GoLectric is an app that determines the amount of money saved if you drove an electric car.");
        firstScreen.setImage(R.drawable.cargraphic);
        firstScreen.setEditVisibility(false);
        firstScreen.setButtonVisbility(false);

        OnboardingItem secondScreen = new OnboardingItem();
        secondScreen.setTitle(" ");
        secondScreen.setDescription("Please enter your vehicle's MPG below so GoLectric can track potential money saved as you drive your current car.");
        secondScreen.setImage(R.drawable.money);
        secondScreen.setMpg("");

        onboardingItems.add(firstScreen);
        onboardingItems.add(secondScreen);

        onboardingAdapter = new OnboardingAdapter(onboardingItems);
    }

    private void setupOnboardingIndicators(){
        ImageView[] indicators = new ImageView[onboardingAdapter.getItemCount()];
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(8, 0, 8, 0);
        for(int i = 0; i < indicators.length; i++){
            indicators[i] = new ImageView(getApplicationContext());
            indicators[i].setImageDrawable(ContextCompat.getDrawable(
                    getApplicationContext(), R.drawable.onboarding_indicator_inactive));
            indicators[i].setLayoutParams(layoutParams);
            layoutOnboardingIndicators.addView(indicators[i]);
        }


    }

    private void setCurrentOnboardingIndicator(int index){
        int childCount = layoutOnboardingIndicators.getChildCount();
        for(int i = 0; i < childCount; i++){
            ImageView imageView = (ImageView) layoutOnboardingIndicators.getChildAt(i);
            if(i == index){
                imageView.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.onboarding_indicator_active));
            }else{
                imageView.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.onboarding_indicator_inactive));
            }




        }
    }

    public void setMPG(EditText mpg)
    {
        this.mpg = mpg;
    }
}
