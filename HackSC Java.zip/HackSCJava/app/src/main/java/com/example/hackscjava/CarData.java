package com.example.hackscjava;

public class CarData
{
    private float MPG;
    private String year;
    private String Make;
    private String Model;
    private long odometer;

    public float getMPG() {
        return MPG;
    }

    public void setMPG(float MPG) {
        this.MPG = MPG;
    }

    public String getMake() {
        return Make;
    }

    public void setMake(String make) {
        Make = make;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        Model = model;
    }

    public long getOdometer() {
        return odometer;
    }

    public void setOdometer(long odometer) {
        this.odometer = odometer;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
