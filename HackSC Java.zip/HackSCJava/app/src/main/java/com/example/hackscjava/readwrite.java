package com.example.hackscjava;
import java.io.*;
import java.util.*;

public class readwrite {

    private float distance;
    private float mpg;
    private String make;
    private String model;
    private String year;
    private String date;

    public readwrite()
    {
    }

    public void readFile(File filename)
    {
        try {
            Scanner s = new Scanner(filename);
            make = s.nextLine();
            model = s.nextLine();
            year = s.nextLine();
            date = s.nextLine();
            mpg = s.nextFloat();
            distance = s.nextFloat();
        }catch(Exception e)
        {

        }
    }
    public void writeFile(File filename,String make,String model,String year,String date,float mpg,float distance)
    {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(filename);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
            bw.write(make);
            bw.newLine();
            bw.write(model);
            bw.newLine();
            bw.write(year);
            bw.newLine();
            bw.write(date);
            bw.newLine();
            bw.write(Float.toString(mpg));
            bw.newLine();
            bw.write(Float.toString(distance));
            bw.newLine();
        }catch(Exception e)
        {
        }
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public float getMpg() {
        return mpg;
    }

    public void setMpg(float mpg) {
        this.mpg = mpg;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
