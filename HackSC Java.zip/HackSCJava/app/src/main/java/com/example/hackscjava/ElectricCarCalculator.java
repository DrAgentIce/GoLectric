package com.example.hackscjava;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class ElectricCarCalculator
{
    //some of the most popular electric cars in 2019, where averaged for this value
    //#3 Chevrolet Bolt EV -  Miles per watt(3.6mpKwh), battery cost(7,800), miles per replacement(100,000)
    //#2 Tesla Model X - Miles per watt(3.4mpKwh), battery cost(7,000), miles per replacement(125,000)
    //#5 Nissan Leaf - Miles per watt(3.0mpKwh), battery cost(5,499), miles per replacement(100,000)
    ElectricCar average = new ElectricCar(3.33f,6766f, 108000);
    String state;

    ElectricCarCalculator(Context context, Location location)
    {
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        try {
            double lat = location.getLatitude();
            double lon = location.getLongitude();
           List<Address> address = geocoder.getFromLocation(lat,lon,1);
           state = address.get(0).getAdminArea();
        }catch (IOException e)
        {
            e.getStackTrace();
        }
    }

    public String getState()
    {
        return state;
    }

    public float CarbonEmissionGas(float distance, CarData car)
    {
        return 8.78f*(distance/car.getMPG());
    }
    public float CarbonEmissionElectric(float distance)
    {
        return 0.4483f*(distance/average.getMilesPerkiloWatt());
    }
    public float CarbonEmissionSavedByElectric(float distance, CarData car)
    {
        return Math.abs(CarbonEmissionGas(distance,car) - CarbonEmissionElectric(distance));
    }

    public float PriceGas(float distance, CarData car)
    {
        GasbyState gasbyState = new GasbyState();
        float cost = gasbyState.getGasCost(state);
        //TODO multiply price of gas per gallon by gallons used
        return (distance/car.getMPG())*cost;
    }
    public float PriceElectric(float distance)
    {
        //TODO multiply price of electicity per kWh by kwh used
        ElectricitybyState electricitybyState = new ElectricitybyState();
        float cost = electricitybyState.getElectricityCost(state);
        return ((distance/average.getMilesPerkiloWatt())*cost);
    }
    public float Pricedifference(float distance, CarData car)
    {
        return PriceGas(distance, car) - PriceElectric(distance);
    }



}

class ElectricCar
{

    private float milesPerkiloWatt;
    private float batteryCost;
    private long milePerReplacement;

    public ElectricCar(float milesPerkiloWatt, float batteryCost, long milePerReplacement) {

        this.milePerReplacement = milePerReplacement;
        this.milesPerkiloWatt = milesPerkiloWatt;
        this.batteryCost = batteryCost;
    }

    public float getMilesPerkiloWatt() {
        return milesPerkiloWatt;
    }

    public void setMilesPerkiloWatt(float milesPerkiloWatt) {
        this.milesPerkiloWatt = milesPerkiloWatt;
    }

    public float getBatteryCost() {
        return batteryCost;
    }

    public void setBatteryCost(float batteryCost) {
        this.batteryCost = batteryCost;
    }

    public long getMilePerReplacement() {
        return milePerReplacement;
    }

    public void setMilePerReplacement(long milePerReplacement) {
        this.milePerReplacement = milePerReplacement;
    }
}
