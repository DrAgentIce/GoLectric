package com.example.hackscjava;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.TreeMap;

public class ElectricitybyState {

    private TreeMap<String,Float> electricityList;

    public ElectricitybyState() {
        try {
            FileReader carFile = new FileReader("com/example/hackscjava/ElectrisityPerState.json");
            Gson gson = new Gson();

            Type collectionType = new TypeToken<TreeMap<String,Float>>(){}.getType();

            JsonReader reader = new JsonReader(carFile);
            electricityList = gson.fromJson(reader, collectionType);
        }catch (FileNotFoundException e)
        {
        }
    }

    public float getElectricityCost(String state)
    {
        return electricityList.get(state);
    }
}
