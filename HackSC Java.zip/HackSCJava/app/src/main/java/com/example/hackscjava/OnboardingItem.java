package com.example.hackscjava;

public class OnboardingItem {
    private int image;
    private String title;
    private String description;
    private String mpgNum;
    private boolean editVisibility = true;
    private boolean buttonVisbility = true;

    public boolean isButtonVisbility() {
        return buttonVisbility;
    }

    public void setButtonVisbility(boolean buttonVisbility) {
        this.buttonVisbility = buttonVisbility;
    }

    public boolean isEditVisibility() {
        return editVisibility;
    }

    public void setEditVisibility(boolean editVisibility) {
        this.editVisibility = editVisibility;
    }

    public String getMpg() {
        return mpgNum;
    }

    public void setMpg(String mpgNum) {
        this.mpgNum = mpgNum;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
