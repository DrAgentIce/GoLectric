package com.example.hackscjava;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.ArrayList;


public class CarDatabase
{
    ArrayList<car> carDatabase;
    CarDatabase()
    {
        try {
            FileReader carFile = new FileReader("Mpgfinal.json");
            Gson gson = new Gson();

            Type collectionType = new TypeToken<ArrayList<car>>(){}.getType();

            JsonReader reader = new JsonReader(carFile);
            carDatabase = gson.fromJson(reader, collectionType);
        }catch (FileNotFoundException e)
        {
        }
    }


public ArrayList<String> FindMake(String make)
{
    ArrayList<String> models = new ArrayList<>();
    for (int i = 0; i < carDatabase.size(); i++)
    {
     if (carDatabase.get(i).Make == make)
     {
         models.add(carDatabase.get(i).Model);
     }
    }
    return models;
}

public ArrayList<Float> Findyears(String model,String make) {
    ArrayList<car> models = new ArrayList<>();
    for (int i = 0; i < carDatabase.size(); i++) {
        if (carDatabase.get(i).Make == make) {
            models.add(carDatabase.get(i));
        }
    }
    ArrayList<Float> years = new ArrayList<>();
    for (int i = 0; i < models.size(); i++) {
        if (models.get(i).Model == model) {
            years.add(models.get(i).year);
        }
    }
    return years;
}

public float getMPG(String make,String model, float year)
{
    ArrayList<car> models = new ArrayList<>();
    for (int i = 0; i < carDatabase.size(); i++) {
        if (carDatabase.get(i).Make == make) {
            models.add(carDatabase.get(i));
        }
    }
    ArrayList<car> years = new ArrayList<>();
    for (int i = 0; i < models.size(); i++) {
        if (models.get(i).Model == model) {
            years.add(models.get(i));
        }
    }
    for (int i = 0; i < years.size(); i++) {
        if (years.get(i).Make == make)
        {
        return years.get(i).MPG;
        }
    }
    return 0;

}



}
 class car
{
    String Make;
    String Model;
    Float MPG;
    Float year;
}