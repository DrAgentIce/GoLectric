package com.example.hackscjava;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.Map;

public class GasbyState {

    private Map<String,Float> gasList;

    public GasbyState() {
        try {
            FileReader carFile = new FileReader("com/example/hackscjava/GasPrices.json");
            Gson gson = new Gson();

            Type collectionType = new TypeToken<Map<String,Float>>(){}.getType();

            JsonReader reader = new JsonReader(carFile);
            gasList = gson.fromJson(reader, collectionType);
        }catch (FileNotFoundException e)
        {
            System.out.println("no Sutch File");
        }
    }

    public float getGasCost(String state)
    {
        return gasList.get(state);
    }
}
